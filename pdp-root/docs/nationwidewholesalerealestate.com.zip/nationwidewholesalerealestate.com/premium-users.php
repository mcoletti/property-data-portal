<?php
$title = "Premium Users";
include "header.php"
?>
<h1><?php echo $title ?></h1>
<?php include "footer.php" ?>
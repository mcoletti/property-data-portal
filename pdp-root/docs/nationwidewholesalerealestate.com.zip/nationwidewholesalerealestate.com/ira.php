<?php
	$title = "IRA's";
	include "header.php"
?>
<h1><?php echo $title ?></h1>
<p>(Coming soon)</p>
<?php include "footer.php" ?>
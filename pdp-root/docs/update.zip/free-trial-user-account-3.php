<?php
$title = "Free Trial User Account Confirmation";
$category = "full-width";
include "header.php"
?>
<h1><?php echo $title ?></h1>
<p class="block">Thank you for setting up your free trial account.</p>
<?php include "footer.php" ?>
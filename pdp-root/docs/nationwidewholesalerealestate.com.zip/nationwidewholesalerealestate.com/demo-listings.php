	<li class="block">
		<div class="listing-col-left">
			<a href="property.php"> <img src="img/properties/thumb-3133-gerrard.jpg" class="shadow"> </a>
		</div>
		<div class="listing-col-middle">
			<h2>Indianapolis 46226</h2>
			<p class="short-description">
				3 Bed / 1.5 Bath / 0 Garage / 1100sqft / Built
			</p>
			<p class="long-description">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
			</p>
			<table>
				<thead>
					<tr>
						<th>Net Yield:</th>
						<th>Cash Flow /mo:</th>
						<th>Cash Flow /yr:</th>
						<th>Price /sqft:</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>10%</td>
						<td>$625</td>
						<td>$7,500</td>
						<td>$69</td>
					</tr>
				</tbody>
			</table>
		</div><!-- listing-col-middle -->
		<div class="listing-col-right">
			<table class="">
				<tr>
					<th colspan="2"> Wholesale </th>
				</tr>
				<tr>
					<td colspan="2"> $75,900 </td>
				</tr>
				<tr>
					<th>Net Yield</th>
					<th>Bed / Bath</th>
				</tr>
				<tr>
					<td>10%</td>
					<td>3/1.5</td>
				</tr>
			</table>
			<a class="button" href="property.php">View Property</a>
		</div><!-- listing-col-right -->
	</li>
	<li class="block">
		<div class="listing-col-left">
			<a href="property.php"> <img src="img/properties/thumb-2708-hawthorne.jpg" class="shadow"> </a>
		</div>
		<div class="listing-col-middle">
			<h2>Indianapolis 46226</h2>
			<p class="short-description">
				3 Bed / 1.5 Bath / 0 Garage / 1100sqft / Built
			</p>
			<p class="long-description">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
			</p>
			<table>
				<thead>
					<tr>
						<th>Net Yield:</th>
						<th>Cash Flow /mo:</th>
						<th>Cash Flow /yr:</th>
						<th>Price /sqft:</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>10%</td>
						<td>$625</td>
						<td>$7,500</td>
						<td>$69</td>
					</tr>
				</tbody>
			</table>
		</div><!-- listing-col-middle -->
		<div class="listing-col-right">
			<table class="">
				<tr>
					<th colspan="2"> Wholesale </th>
				</tr>
				<tr>
					<td colspan="2"> $75,900 </td>
				</tr>
				<tr>
					<th>Net Yield</th>
					<th>Bed / Bath</th>
				</tr>
				<tr>
					<td>10%</td>
					<td>3/1.5</td>
				</tr>
			</table>
			<a class="button" href="property.php">View Property</a>
		</div><!-- listing-col-right -->
	</li>
	<li class="block">
		<div class="listing-col-left">
			<a href="property.php"> <img src="img/properties/thumb-3218-welch-dr.jpg" class="shadow"> </a>
		</div>
		<div class="listing-col-middle">
			<h2>Indianapolis 46226</h2>
			<p class="short-description">
				3 Bed / 1.5 Bath / 0 Garage / 1100sqft / Built
			</p>
			<p class="long-description">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
			</p>
			<table>
				<thead>
					<tr>
						<th>Net Yield:</th>
						<th>Cash Flow /mo:</th>
						<th>Cash Flow /yr:</th>
						<th>Price /sqft:</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>10%</td>
						<td>$625</td>
						<td>$7,500</td>
						<td>$69</td>
					</tr>
				</tbody>
			</table>
		</div><!-- listing-col-middle -->
		<div class="listing-col-right">
			<table class="">
				<tr>
					<th colspan="2"> Wholesale </th>
				</tr>
				<tr>
					<td colspan="2"> $75,900 </td>
				</tr>
				<tr>
					<th>Net Yield</th>
					<th>Bed / Bath</th>
				</tr>
				<tr>
					<td>10%</td>
					<td>3/1.5</td>
				</tr>
			</table>
			<a class="button" href="property.php">View Property</a>
		</div><!-- listing-col-right -->
	</li>
<?php
$title = "How it Works";
$category = "full-width";
include "header.php"
?>
<h1>
	<img src="img/infographic-how-it-works.png" alt="How Nationwide Property Management works" style="width:100%; height:auto;">
</h1>
<p style="text-align:center;"><a class="button" href="buyers.php#form-registration" style="margin-left:85px; font-size:24pt !important; padding:30px 40px;">Register Now!</a></p>
<?php include "footer.php" ?>
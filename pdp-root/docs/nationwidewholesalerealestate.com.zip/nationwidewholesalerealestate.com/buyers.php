<?php
$title = "Portal for Buyers";
$category = "form-buyers";
include "header.php"
?>
<h1><?php echo $title ?></h1>
<?php include "about.php" ?>
<?php include "footer.php" ?>